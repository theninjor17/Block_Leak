import storage

storage.disable_usb_drive()# Write your code here :-)
